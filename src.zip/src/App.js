import React from 'react';
import {  Routes, Route } from 'react-router-dom'; 
import "./App.css"
import Navbar from './Components/Navbar/Navbar';
import About from './Components/About/About';
import Services from './Components/Services/Services';
import Portfolio from './Components/Portfolio/Portfolio';
import Contact from './Components/Contact/Contact';
import Pricing from './Components/Pricing/Pricing';
import Home from './Home';
import WebsiteDesigning from './Components/WebsiteDesigning';
import WebDevlopment from './Components/WebDevlopment';
import DigitalMarketing from './Components/DigitalMarketing';
import Talk from './Components/Talk';
const App = () => {
  return (
    <div className='App'>       
        <Navbar />
        <Routes>
        <Route path='/' element={<Home />} />
          <Route path='/service' element={<Services />} />
          <Route path="/about" element={<About />} />
          <Route path="/pricing" element={<Pricing />} />
          <Route path="/portfolio" element={<Portfolio />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/website-designing" element={<WebsiteDesigning />} />
          <Route path="/web-development" element={<WebDevlopment />} />
          <Route path="/digital-marketing" element={< DigitalMarketing/>} />
          <Route path="/Talk-To-Expert" element={<Talk/>} />
          
        </Routes>
      
    </div>
  );
}

export default App;
