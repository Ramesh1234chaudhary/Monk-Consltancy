import React from 'react'

const DigitalMarketing = () => {
  return (
    <div style={{color:"white"}}>
       jjjjj
    </div>
  )
}

export default DigitalMarketing;
