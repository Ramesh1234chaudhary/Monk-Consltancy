import React from 'react'

const Pricing = () => {
  return (
    <div style={{color:"white"}}>Pricing hhhiii</div>
  )
}

export default Pricing;