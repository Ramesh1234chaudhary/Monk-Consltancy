import React from 'react'
import "./Services2.css"
const Services2 = () => {
    return (
        <div className='services'>
            <h1>Let's check our services.</h1>
            <div className='main-services' style={{ color: 'white'  }} >
                <div className='child'>
                    <img src='./web.png' />
                    <h3>Digital Marketing</h3>
                    <h6>The world is going online and so are brands so as to get their clients.
                         India houses the second highest web user base on the planet...

                    </h6>
                </div>
                <div className='child'>
                <img src='./web.png' />
                    <h3>Web Development</h3>
                    <h6>Web development broadly refers to the tasks associated with creating websites
                         for hosting through intranet or websites...</h6>
                </div>
 
                <div className='child'>
                <img src='./web.png' />
                    <h3>Website Designing</h3>
                    <h6>Website designing plays an important role for your business since it is your website
                         which act as the spokesperson for your business and it is the nature... </h6>
                </div>
                <div className='child'>
                <img src='./web.png' />
                    <h3>Web Hosting</h3>
                    <h6>The web hosting simply means hiring space on server which allows an individual or a 
                         company to make their website visible on internet via web protocol. Weblooks IT...</h6>
                </div>

                <div className='child'>
                <img src='./web.png' />
                    <h3>Domains Purchase</h3>
                    <h6>We provide all types of domains for purchase as per client requirement and integrate the same along with hosting.
                  </h6>
                </div>

                <div className='child'>
                <img src='./web.png' />
                    <h3>Graphic Design </h3>
                    <h6>Weblooks IT Services offers complete graphic design services to promote your company or brand. Believing in the adage...
                    </h6>
                </div>
                <div className='child'>
                <img src='./web.png' />
                    <h3>Other Services</h3>
                    <h6>We also provide additional services to our customers. Services like Website Maintenance, Bulk E-Mail/SMS, google apps e-mail,...
                   </h6>
                </div>
                <div className='child'>
                <img src='./web.png' />
                    <h3>App Development</h3>
                    <h6>We are the leading software development company that can provide cost effective solution for the improvement of a business. Empower the digital world with innovative application for your...
                    </h6>
                </div>


            </div>

        </div>
    )
}

export default Services2