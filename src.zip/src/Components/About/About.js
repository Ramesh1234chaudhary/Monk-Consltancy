import React from 'react'

const About = () => {
  return (
    <div style={{color:'white'}}> hii</div>
  )
}

export default About;