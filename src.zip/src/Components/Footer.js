import React from 'react'
import "./Footer.css"
import { NavLink } from 'react-router-dom';
const Footer = () => {
    return (
        <div className='main-footer'>
            <div className='footer-top'>
                <div className='talk-to-our-expert'>
                    <NavLink to="/Talk-To-Expert" >  <button style={{ color: "white", }} className='move-up-button'>
                        <img src='./call icon.png' style={{ width: "20px", paddingRight: "10px", paddingTop: "10px" }} />
                        Talk To Our Expert   <div className='loading-dots' style={{ marginTop: "-10px", marginRight: "20px" }}>
                            <span></span>
                            <span></span>
                            <span></span>
                        </div></button> </NavLink>
                </div>
                <div className='footer-content'>
                    <div className='content1'>
                        <h6 style={{ color: "white" }}>usefull links</h6>


                        <p>Domain Registration</p>
                        <p>Hosting Registration</p>
                        <p>Static Website</p>
                        <p>Packages</p>
                        <p>Carrer</p>


                    </div>
                    <div className='content2'>
                        <h6></h6>
                        <p>Write A Review</p>
                        <p>Term && Conditions</p>
                        <p>Privacy Policy</p>
                        <p>Affiliate Program</p>
                        <p>FAQ</p>

                    </div>

                    <div className='content3'>
                        <h6 style={{ color: "white" }}>Web services</h6>
                       <p> Website Designing</p>
                       <p>Web Hosting</p>
                       <p> Graphic Design</p>
                       <p> Web Development</p>
                       <p> Digital Marketing</p>
                       <p> App Development</p>
                       <p> Other Services </p>

                    </div>

                    <div className='content4'>
                        <h6 style={{ color: "white" }}>conect with us</h6>
                    </div>

                    <div className='content5'>
                        <h6 style={{ color: "white" }}>Follow us on</h6>
                    </div>
                </div>
            </div>
            <div className='footer-bottom'>
                <div className='footer-left'>
                    <img src='./leaf.png' className='leaf' />
                    <img src='./women.png' className='women-image' />

                </div>
                <div className='footer-middle'>
                    <img src='./people.png' />


                </div>
                <div className='footer-right'>
                    <img src='./man.png' className='man-image' />
                    <img src='./leaf2.png' className='leaf2' />


                </div>
            </div>
        </div>
    )
}

export default Footer;