import React from 'react';
import { NavLink } from 'react-router-dom';
import './Navbar.css';
import { useState } from 'react';
import Model from '../Model';

const data = ["Web Application Development", "E-commerce Website", "Digital Marketing",
    "Web App Development", "Domain && Hoisting Services", "Customized Software Development"]

const Navbar = () => {
    const [showmodel ,setShowmodel]=useState(false)



    return (
        <div className='navbar'>
            <div className='logo'>
                <img src='./logo.jpg' alt='image3' />
            </div>
            <div className='main-heading'>
                <div className='heading'>
                    <NavLink to="/" className="nav-link"><img src='https://static.vecteezy.com/system/resources/previews/011/934/380/original/silver-home-icon-free-png.png' /></NavLink>
                    <NavLink to="/About" className="nav-link"><h5>About Us</h5></NavLink>
                    <NavLink to="/services" className="nav-link"><h5>Services</h5></NavLink>
                    <NavLink to="/pricing" className="nav-link"><h5>Pricing</h5></NavLink>
                    <NavLink to="/portfolio" className="nav-link"><h5>Portfolio</h5></NavLink>
                    <NavLink to="/contact" className="nav-link"><h5>Contact Us</h5></NavLink>
                
                        <button className='button' onClick={()=>setShowmodel(true)}>Get a quote <div className='loading-dots'>
                            <span></span>
                            <span></span>
                            <span></span> 
                        </div></button>
                        
                </div>
                { showmodel && <Model setShowmodel={setShowmodel}/> }
            </div>

          
        </div>
    );
}

export default Navbar;
