import React from 'react'

const Contact = () => {
  return (
    <div style={{color:'white'}}>Contact hii</div>
  )
}

export default Contact;