import React from 'react'

const Portfolio = () => {
  return (
    <div style={{color:'white'}}>Portfolio</div>
  )
}

export default Portfolio;