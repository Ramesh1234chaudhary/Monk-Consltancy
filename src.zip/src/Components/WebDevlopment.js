import React from 'react'

const WebDevlopment = () => {
  return (
    <div style={{color:"white"}}>WebDevlopment</div>
  )
}

export default WebDevlopment;