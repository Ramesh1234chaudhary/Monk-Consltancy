import React from 'react'
import "./Servicec.css"
const Services = () => {
  return (
    <div style={{color:'white'}}>Services hii</div>
  )
}

export default Services;