import React from 'react'

const Talk = () => {
  return (
    <div style={{color:"white"}}>Talk-To-Expert</div>
  )
}

export default Talk;